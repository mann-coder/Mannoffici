module.exports = {
  TELEGRAM_BOT_TOKEN: '7997991332:AAFTl4PETTkFYMtzTdAPJJgAdY311AaVSuw',
  ADMIN_IDS: [7025203900], // ID admin yang diizinkan
  FUNCTION_DIR: './functions',
  CASE_DIR: './cases'
};