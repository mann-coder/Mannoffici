const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');
const config = require('./config');

// Buat direktori jika belum ada
if (!fs.existsSync(config.FUNCTION_DIR)) fs.mkdirSync(config.FUNCTION_DIR);
if (!fs.existsSync(config.CASE_DIR)) fs.mkdirSync(config.CASE_DIR);

const bot = new Telegraf(config.TELEGRAM_BOT_TOKEN);

// Middleware untuk cek admin
bot.use((ctx, next) => {
  if (!config.ADMIN_IDS.includes(ctx.from.id)) {
    return ctx.reply('Maaf, hanya admin yang bisa menggunakan bot ini.');
  }
  return next();
});

// Command /start
bot.start((ctx) => {
  ctx.reply('🤖 Bot Manajemen Fungsi JavaScript\n\n' +
    '/addfunc - Upload file fungsi JS\n' +
    '/addcase - Upload file test case JS\n' +
    '/listfunc - Daftar fungsi yang tersedia');
});

// Handle /addfunc - Upload file fungsi
bot.command('addfunc', (ctx) => {
  ctx.reply('Silakan upload file JavaScript berisi fungsi yang ingin ditambahkan.');
});

// Handle /addcase - Upload file test case
bot.command('addcase', (ctx) => {
  ctx.reply('Silakan upload file JavaScript berisi test case untuk fungsi tertentu.');
});

// Handle file document (fungsi)
bot.on('document', async (ctx) => {
  const file = ctx.message.document;
  
  if (!file.file_name.endsWith('.js')) {
    return ctx.reply('Hanya file JavaScript (.js) yang diterima.');
  }

  try {
    // Download file
    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    const response = await fetch(fileLink);
    const fileContent = await response.text();
    
    // Simpan file
    let savePath;
    if (ctx.message.caption === '/addfunc') {
      savePath = path.join(config.FUNCTION_DIR, file.file_name);
    } else if (ctx.message.caption === '/addcase') {
      savePath = path.join(config.CASE_DIR, file.file_name);
    } else {
      return ctx.reply('Gunakan command /addfunc atau /addcase sebagai caption file.');
    }

    fs.writeFileSync(savePath, fileContent);
    
    ctx.reply(`File ${file.file_name} berhasil disimpan!`);
  } catch (error) {
    console.error(error);
    ctx.reply('Gagal menyimpan file: ' + error.message);
  }
});

// Command /listfunc - List semua fungsi
bot.command('listfunc', (ctx) => {
  try {
    const funcFiles = fs.readdirSync(config.FUNCTION_DIR);
    
    if (funcFiles.length === 0) {
      return ctx.reply('Belum ada fungsi yang tersedia.');
    }

    let message = '📁 Daftar Fungsi:\n\n';
    funcFiles.forEach(file => {
      message += `🔹 ${file}\n`;
    });

    ctx.reply(message);
  } catch (error) {
    ctx.reply('Error membaca direktori fungsi: ' + error.message);
  }
});

// Jalankan bot
bot.launch()
  .then(() => console.log('Bot berjalan...'))
  .catch(err => console.error('Bot error:', err));

// Handle shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));